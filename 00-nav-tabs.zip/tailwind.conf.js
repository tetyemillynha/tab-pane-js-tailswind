// tailwind.config.js
module.exports = {
    theme: {},
    variants: {},
    plugins: [],
}